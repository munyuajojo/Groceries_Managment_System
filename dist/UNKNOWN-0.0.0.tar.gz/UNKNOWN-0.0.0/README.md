# This is my first Inventory Management System.

This is a simple inventory managment system that allows users to create an inventory, add inventory stock and track the sales made. 

